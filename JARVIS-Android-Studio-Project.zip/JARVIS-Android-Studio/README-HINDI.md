# JARVIS AI — Android Studio Project

Yeh Android app ka source project hai. Yeh **ready-made APK nahi** hai; APK banane ke liye Android Studio mein build karna hoga.

## App mein kya kaam karta hai?
- Hindi voice input (phone ki speech-recognition service par depend karta hai)
- Text-to-speech jawab
- Time aur date batana
- YouTube / Google kholna
- Google search kholna
- Notes save aur screen par dikhana

## APK banane ke steps (computer/laptop par)
1. Android Studio ko official site `https://developer.android.com/studio` se install karein.
2. ZIP ko extract karein.
3. Android Studio kholein → **Open** → extracted `JARVIS-Android-Studio` folder select karein.
4. Agar Android SDK 35 maange to SDK Manager se Android 15 / API 35 install karein. Gradle sync complete hone dein; internet chahiye ho sakta hai.
5. Phone ko USB se connect karein aur Developer options → USB debugging on karein, ya Android Studio ka emulator use karein.
6. Pehle green **Run ▶** dabakar test karein. Microphone permission allow karein.
7. APK banane ke liye: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
8. Build complete hone par notification mein **Locate** dabayein. APK aam taur par `app/build/outputs/apk/debug/app-debug.apk` mein hogi.
9. APK phone par copy karke open karein. Zarurat par Android settings mein us file manager/browser ko **Install unknown apps** permission dein. Sirf apne banaye/trusted APK ko install karein.

## Sirf mobile hai?
Android Studio aam taur par computer/laptop par chalta hai. Sirf phone se build karna mumkin ho sakta hai, lekin zyada mushkil hai. Kisi unknown APK website par project upload na karein.

## Zaroori limitations
- Voice recognition ke liye compatible Android speech service aur aksar internet chahiye.
- App sirf mic button dabane par sunta hai; background mein hamesha nahi sunta.
- Yeh demo command-based assistant hai, ChatGPT jaisa general AI nahi. Online AI answers ke liye secure backend/API integration chahiye; API key app ke andar hard-code na karein.
- Phone ko lock/shutdown karna, WhatsApp messages bhejna, ya har app ko automatically control karna is version mein shamil nahi hai.
