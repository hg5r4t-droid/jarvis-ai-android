package com.gamezone.jarvis

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var statusText: TextView
    private lateinit var conversation: TextView
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private val prefs by lazy { getSharedPreferences("jarvis_notes", MODE_PRIVATE) }
    private val requestSpeech = 701
    private val requestAudioPermission = 702
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        addLine("JARVIS", "Namaste! Main JARVIS hoon. Neeche likho ya mic button dabakar bolo.")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            setBackgroundColor(Color.rgb(7, 17, 31))
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S AI"
            textSize = 28f
            setTextColor(Color.rgb(0, 194, 255))
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(4))
        }
        statusText = TextView(this).apply {
            text = "PERSONAL VOICE ASSISTANT"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, dp(16))
        }
        conversation = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(Color.rgb(16, 31, 50))
            text = "Conversation yahan dikhegi.\n\nTry: time batao, date batao, YouTube kholo, Google par cricket search karo, note likho hello, notes dikhao."
        }
        val scroll = ScrollView(this).apply { addView(conversation) }
        input = EditText(this).apply {
            hint = "Yahan apna command likho..."
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 16f
            setSingleLine(true)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val send = makeButton("Send") { runCommand(input.text.toString()); input.setText("") }
        val mic = makeButton("🎙  Bolo (Voice)") { startListening() }
        val help = makeButton("Help / Commands") { speak("Aap time batao, date batao, YouTube kholo, Google kholo, Google par kuch search karo, note likho aur notes dikhao bol sakte hain.") }
        root.addView(title)
        root.addView(statusText)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) })
        root.addView(send, fullWidth())
        root.addView(mic, fullWidth())
        root.addView(help, fullWidth())
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 15f
        setOnClickListener { action() }
    }

    private fun fullWidth() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(5) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Is phone par speech recognition available nahi hai. Aap command type kar sakte hain.")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudioPermission)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS ko command boliye")
        }
        try { startActivityForResult(intent, requestSpeech) }
        catch (_: ActivityNotFoundException) { speak("Voice typing service nahi mili. Command type karke try karein.") }
    }

    @Deprecated("Activity result API kept for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestSpeech && resultCode == RESULT_OK) {
            val result = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (result.isNotBlank()) runCommand(result) else speak("Main aapki baat samajh nahi paya. Dobara try karein.")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestAudioPermission && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startListening()
        else if (requestCode == requestAudioPermission) speak("Voice ke liye microphone permission zaroori hai. Aap type bhi kar sakte hain.")
    }

    private fun runCommand(raw: String) {
        val command = raw.trim()
        if (command.isBlank()) { speak("Pehle kuch likho ya bolo."); return }
        addLine("Aap", command)
        val lower = command.lowercase(Locale.ROOT)
        when {
            lower.contains("time") || lower.contains("समय") || lower.contains("kitne baje") -> speak("Abhi time hai " + SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()))
            lower.contains("date") || lower.contains("tareekh") || lower.contains("तारीख") -> speak("Aaj ki date hai " + SimpleDateFormat("dd MMMM yyyy", Locale("hi", "IN")).format(Date()))
            lower.contains("youtube") && (lower.contains("open") || lower.contains("kholo") || lower.contains("chala")) -> openUrl("https://www.youtube.com", "YouTube")
            lower.contains("google kholo") || lower.contains("open google") -> openUrl("https://www.google.com", "Google")
            lower.contains("search") || lower.contains("सर्च") || lower.contains("dhundo") -> {
                val query = command.replace(Regex("(?i)google|search|सर्च|par|पर|dhundo|ढूंढो|karo|करो"), " ").trim()
                if (query.isBlank()) speak("Kya search karna hai? Jaise: Google par cricket search karo")
                else openUrl("https://www.google.com/search?q=" + android.net.Uri.encode(query), "Google search")
            }
            lower.startsWith("note likho") || lower.startsWith("note banao") || lower.startsWith("save note") || lower.startsWith("नोट लिखो") -> {
                val note = command.replace(Regex("(?i)^(note likho|note banao|save note|नोट लिखो)\\s*"), "").trim()
                val all = prefs.getString("notes", "").orEmpty()
                val updated = (all.lines().filter { it.isNotBlank() } + "• $note").takeLast(50).joinToString("\n")
                prefs.edit().putString("notes", updated).apply()
                speak(if (note.isBlank()) "Note ke baad apna message bhi likhein." else "Aapka note save ho gaya.")
            }
            lower.contains("notes dikhao") || lower.contains("show notes") || lower.contains("mere notes") -> {
                val notes = prefs.getString("notes", "").orEmpty().ifBlank { "Abhi koi note save nahi hai." }
                addLine("JARVIS", notes); speak("Aapke notes screen par dikha diye hain.")
            }
            lower.contains("help") || lower.contains("madad") || lower.contains("commands") -> speak("Aap time batao, date batao, YouTube kholo, Google kholo, Google par cricket search karo, note likho hello, aur notes dikhao bol sakte hain.")
            lower.contains("hello") || lower.contains("hi") || lower.contains("namaste") || lower.contains("नमस्ते") -> speak("Namaste! Bataiye main aapki kya madad karun?")
            else -> speak("Abhi main is command ko nahi samajh paya. Help button dabakar available commands dekhein.")
        }
    }

    private fun openUrl(url: String, name: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)))
            speak("$name khol raha hoon.")
        } catch (_: Exception) { speak("$name open nahi ho paya. Internet connection check karein.") }
    }

    private fun addLine(who: String, message: String) {
        val old = conversation.text.toString()
        conversation.text = (old + "\n\n$who: $message").takeLast(6000)
    }

    private fun speak(message: String) {
        addLine("JARVIS", message)
        if (ttsReady) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_${System.currentTimeMillis()}")
        statusText.text = "READY • JARVIS ACTIVE"
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            val result = tts.setLanguage(Locale("hi", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) tts.language = Locale.US
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
